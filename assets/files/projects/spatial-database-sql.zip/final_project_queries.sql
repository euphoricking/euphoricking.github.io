-- Creating the Database
CREATE DATABASE festival_db;


-- Enable PostGIS extension (if not already enabled)
CREATE EXTENSION IF NOT EXISTS postgis;


-- 1. Festival Information

-- For simplicity, we assume one festival record.
CREATE TABLE festival_info (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  description TEXT
);

INSERT INTO festival_info (name, start_date, end_date, description)
VALUES 
  ('City Festival 2025', '2025-06-01', '2025-06-05', 'Annual city festival featuring events, attractions, and facilities.');


-- 2. Facility Table

CREATE TABLE facility (
  id SERIAL PRIMARY KEY,
  festival_id INT REFERENCES festival_info(id),
  name VARCHAR(100) NOT NULL,
  type VARCHAR(50) NOT NULL, 
  location GEOMETRY(Point, 4326) NOT NULL,
  opening_time TIME,
  closing_time TIME
);


INSERT INTO facility (festival_id, name, type, location, opening_time, closing_time)
VALUES 
  (1, 'Main Toilet A', 'Toilet', ST_SetSRID(ST_MakePoint(13.0450, 47.8100), 4326), '08:00', '22:00'),
  (1, 'Garbage Bin 1', 'Garbage Bin', ST_SetSRID(ST_MakePoint(13.0500, 47.8120), 4326), NULL, NULL),
  (1, 'First Aid Station', 'First Aid', ST_SetSRID(ST_MakePoint(13.0480, 47.8110), 4326), '08:00', '22:00'),
  (1, 'Information Booth', 'Info', ST_SetSRID(ST_MakePoint(13.0460, 47.8090), 4326), '09:00', '21:00'),
  (1, 'Rest Area', 'Rest', ST_SetSRID(ST_MakePoint(13.0490, 47.8150), 4326), '10:00', '20:00'),
  (1, 'Mobile Charging Station', 'Charging', ST_SetSRID(ST_MakePoint(13.0470, 47.8160), 4326), '10:00', '22:00'),
  (1, 'Water Fountain', 'Water', ST_SetSRID(ST_MakePoint(13.0440, 47.8100), 4326), '08:00', '22:00'),
  (1, 'Security Post', 'Security', ST_SetSRID(ST_MakePoint(13.0510, 47.8130), 4326), '07:00', '23:00'),
  (1, 'Lost & Found', 'Info', ST_SetSRID(ST_MakePoint(13.0485, 47.8140), 4326), '09:00', '21:00'),
  (1, 'Snack Kiosk', 'Kiosk', ST_SetSRID(ST_MakePoint(13.0455, 47.8120), 4326), '10:00', '20:00');


-- 3. Event Table

CREATE TABLE event (
  id SERIAL PRIMARY KEY,
  festival_id INT REFERENCES festival_info(id),
  name VARCHAR(100) NOT NULL,
  description TEXT,
  start_time TIMESTAMP NOT NULL,
  end_time TIMESTAMP NOT NULL,
  location GEOMETRY(Point, 4326) NOT NULL
);


INSERT INTO event (festival_id, name, description, start_time, end_time, location)
VALUES 
  (1, 'Opening Ceremony', 'Kick-off event for the festival', '2025-06-01 10:00', '2025-06-01 11:00', ST_SetSRID(ST_MakePoint(13.0470, 47.8110), 4326)),
  (1, 'Concert in the Park', 'Live music performance', '2025-06-02 18:00', '2025-06-02 20:00', ST_SetSRID(ST_MakePoint(13.0490, 47.8130), 4326)),
  (1, 'Art Exhibition', 'Local artists display their work', '2025-06-03 14:00', '2025-06-03 17:00', ST_SetSRID(ST_MakePoint(13.0440, 47.8150), 4326)),
  (1, 'Street Performance', 'Theatrical and musical street acts', '2025-06-01 12:00', '2025-06-01 13:00', ST_SetSRID(ST_MakePoint(13.0500, 47.8100), 4326)),
  (1, 'Food Tasting', 'Experience local cuisine', '2025-06-02 12:00', '2025-06-02 14:00', ST_SetSRID(ST_MakePoint(13.0460, 47.8120), 4326)),
  (1, 'Dance Workshop', 'Interactive dance session', '2025-06-03 16:00', '2025-06-03 18:00', ST_SetSRID(ST_MakePoint(13.0480, 47.8160), 4326)),
  (1, 'Fireworks Display', 'Spectacular end-of-day fireworks', '2025-06-05 21:00', '2025-06-05 21:30', ST_SetSRID(ST_MakePoint(13.0510, 47.8140), 4326)),
  (1, 'Local Band Performance', 'Showcase of local talent', '2025-06-04 19:00', '2025-06-04 20:30', ST_SetSRID(ST_MakePoint(13.0450, 47.8170), 4326)),
  (1, 'Cultural Parade', 'A festive parade through the city', '2025-06-04 15:00', '2025-06-04 16:30', ST_SetSRID(ST_MakePoint(13.0470, 47.8150), 4326)),
  (1, 'Closing Ceremony', 'Festival wrap-up event', '2025-06-05 22:00', '2025-06-05 23:00', ST_SetSRID(ST_MakePoint(13.0490, 47.8120), 4326));


-- 4. Attraction Table

CREATE TABLE attraction (
  id SERIAL PRIMARY KEY,
  festival_id INT REFERENCES festival_info(id),
  name VARCHAR(100) NOT NULL,
  type VARCHAR(50) NOT NULL,
  geometry GEOMETRY,
  opening_time TIME,
  closing_time TIME
);


INSERT INTO attraction (festival_id, name, type, geometry, opening_time, closing_time)
VALUES 
  (1, 'Food Booth 1', 'Booth', ST_SetSRID(ST_GeomFromText('POLYGON((13.0450 47.8100, 13.0460 47.8100, 13.0460 47.8110, 13.0450 47.8110, 13.0450 47.8100))'), 4326), '09:00', '21:00'),
  (1, 'Roller Coaster', 'Ride', ST_SetSRID(ST_MakePoint(13.0515, 47.8125), 4326), '10:00', '22:00'),
  (1, 'Art Booth', 'Booth', ST_SetSRID(ST_GeomFromText('POLYGON((13.0445 47.8150, 13.0455 47.8150, 13.0455 47.8160, 13.0445 47.8160, 13.0445 47.8150))'), 4326), '10:00', '20:00'),
  (1, 'Game Zone Ride', 'Ride', ST_SetSRID(ST_MakePoint(13.0475, 47.8140), 4326), '11:00', '21:00'),
  (1, 'Tent Stage', 'Tent', ST_SetSRID(ST_GeomFromText('POLYGON((13.0480 47.8160, 13.0490 47.8160, 13.0490 47.8170, 13.0480 47.8170, 13.0480 47.8160))'), 4326), '12:00', '22:00'),
  (1, 'VIP Lounge', 'Booth', ST_SetSRID(ST_GeomFromText('POLYGON((13.0465 47.8170, 13.0475 47.8170, 13.0475 47.8180, 13.0465 47.8180, 13.0465 47.8170))'), 4326), '13:00', '21:00'),
  (1, 'Ferris Wheel', 'Ride', ST_SetSRID(ST_MakePoint(13.0505, 47.8135), 4326), '10:00', '22:00'),
  (1, 'Craft Market', 'Booth', ST_SetSRID(ST_GeomFromText('POLYGON((13.0440 47.8120, 13.0450 47.8120, 13.0450 47.8130, 13.0440 47.8130, 13.0440 47.8120))'), 4326), '09:00', '19:00'),
  (1, 'Kids Play Area', 'Attraction', ST_SetSRID(ST_GeomFromText('POLYGON((13.0435 47.8155, 13.0445 47.8155, 13.0445 47.8165, 13.0435 47.8165, 13.0435 47.8155))'), 4326), '10:00', '18:00'),
  (1, 'Interactive Exhibit', 'Exhibit', ST_SetSRID(ST_GeomFromText('POLYGON((13.0470 47.8180, 13.0480 47.8180, 13.0480 47.8190, 13.0470 47.8190, 13.0470 47.8180))'), 4326), '11:00', '20:00');


-- 5. Zone Table

CREATE TABLE zone (
  id SERIAL PRIMARY KEY,
  festival_id INT REFERENCES festival_info(id),
  name VARCHAR(100) NOT NULL,
  description TEXT,
  area GEOMETRY(Polygon, 4326) NOT NULL
);

-- Insert 10 dynamic zone records
INSERT INTO zone (festival_id, name, description, area)
VALUES 
  (1, 'Food Area', 'Zone designated for food stalls and booths', ST_SetSRID(ST_GeomFromText('POLYGON((13.0440 47.8090, 13.0470 47.8090, 13.0470 47.8130, 13.0440 47.8130, 13.0440 47.8090))'), 4326)),
  (1, 'Entertainment Zone', 'Area for concerts and live shows', ST_SetSRID(ST_GeomFromText('POLYGON((13.0480 47.8100, 13.0510 47.8100, 13.0510 47.8140, 13.0480 47.8140, 13.0480 47.8100))'), 4326)),
  (1, 'Kids Zone', 'Designated safe play area for children', ST_SetSRID(ST_GeomFromText('POLYGON((13.0450 47.8150, 13.0480 47.8150, 13.0480 47.8190, 13.0450 47.8190, 13.0450 47.8150))'), 4326)),
  (1, 'Art Zone', 'Outdoor art installations and exhibitions', ST_SetSRID(ST_GeomFromText('POLYGON((13.0420 47.8120, 13.0450 47.8120, 13.0450 47.8160, 13.0420 47.8160, 13.0420 47.8120))'), 4326)),
  (1, 'VIP Zone', 'Exclusive area for VIP guests', ST_SetSRID(ST_GeomFromText('POLYGON((13.0500 47.8160, 13.0530 47.8160, 13.0530 47.8200, 13.0500 47.8200, 13.0500 47.8160))'), 4326)),
  (1, 'Marketplace', 'Area with vendors and local crafts', ST_SetSRID(ST_GeomFromText('POLYGON((13.0460 47.8070, 13.0490 47.8070, 13.0490 47.8110, 13.0460 47.8110, 13.0460 47.8070))'), 4326)),
  (1, 'Cultural Zone', 'Exhibits showcasing local culture', ST_SetSRID(ST_GeomFromText('POLYGON((13.0480 47.8130, 13.0510 47.8130, 13.0510 47.8170, 13.0480 47.8170, 13.0480 47.8130))'), 4326)),
  (1, 'Game Zone', 'Area dedicated to interactive games and rides', ST_SetSRID(ST_GeomFromText('POLYGON((13.0430 47.8150, 13.0460 47.8150, 13.0460 47.8190, 13.0430 47.8190, 13.0430 47.8150))'), 4326)),
  (1, 'Relaxation Area', 'Quiet space for resting and socializing', ST_SetSRID(ST_GeomFromText('POLYGON((13.0400 47.8100, 13.0430 47.8100, 13.0430 47.8140, 13.0400 47.8140, 13.0400 47.8100))'), 4326)),
  (1, 'Main Stage Area', 'Primary performance area and gathering space', ST_SetSRID(ST_GeomFromText('POLYGON((13.0470 47.8080, 13.0500 47.8080, 13.0500 47.8120, 13.0470 47.8120, 13.0470 47.8080))'), 4326));


-- 6. Spatial Indexes for Performance

CREATE INDEX idx_facility_location ON facility USING GIST (location);
CREATE INDEX idx_event_location ON event USING GIST (location);
CREATE INDEX idx_attraction_geometry ON attraction USING GIST (geometry);
CREATE INDEX idx_zone_area ON zone USING GIST (area);


-- 7. Unified View for Spatial Entities

CREATE VIEW spatial_entities AS
SELECT id, name, 'Facility' AS entity_type, location AS geom
FROM facility
UNION ALL
SELECT id, name, 'Event' AS entity_type, location AS geom
FROM event
UNION ALL
SELECT id, name, 'Attraction' AS entity_type, geometry AS geom
FROM attraction
UNION ALL
SELECT id, name, 'Zone' AS entity_type, area AS geom
FROM zone;


-- SAMPLE SPATIAL QUERIES (USING DYNAMIC PARAMETERS)

-- 1. Find Facilities within 500 Meters of a Given Location
SELECT id, name, type,
       ST_Distance(location, ST_SetSRID(ST_MakePoint(13.045, 47.810), 4326)) AS distance
FROM facility
WHERE ST_DWithin(location, ST_SetSRID(ST_MakePoint(13.045, 47.810), 4326), 500)
ORDER BY distance;

-- 2. Find Events within 500 Meters of a Given Location
SELECT id, name, description, start_time, end_time,
       ST_Distance(location, ST_SetSRID(ST_MakePoint(13.045, 47.810), 4326)) AS distance
FROM event
WHERE start_time > NOW()
  AND ST_DWithin(location, ST_SetSRID(ST_MakePoint(13.045, 47.810), 4326), 500)
ORDER BY start_time;


-- 3. Find Attractions within 1000 Meters of a Given Location
SELECT id, name, type,
       ST_Distance(geometry, ST_SetSRID(ST_MakePoint(13.045, 47.810), 4326)) AS distance
FROM attraction
WHERE ST_DWithin(geometry, ST_SetSRID(ST_MakePoint(13.045, 47.810), 4326), 1000)
ORDER BY distance;

-- 4. Find the Nearest Facility to a Given Location
SELECT id, name, type,
       ST_Distance(location, ST_SetSRID(ST_MakePoint(13.045, 47.810), 4326)) AS distance
FROM facility
ORDER BY location <-> ST_SetSRID(ST_MakePoint(13.045, 47.810), 4326)
LIMIT 1;

-- 5. Find Facilities Inside a Specific Zone
SELECT f.id, f.name, f.type
FROM facility f
JOIN zone z ON ST_Contains(z.area, f.location)
WHERE z.name = 'Food Area';

-- 6. Find the Total Number of Events in Each Zone
SELECT z.name AS zone_name, COUNT(e.id) AS event_count
FROM zone z
LEFT JOIN event e ON ST_Within(e.location, z.area)
GROUP BY z.name
ORDER BY event_count DESC;

-- 7. Find the Number of Facilities within Each Zone
SELECT z.name AS zone_name, COUNT(f.id) AS facility_count
FROM zone z
LEFT JOIN facility f ON ST_Within(f.location, z.area)
GROUP BY z.name
ORDER BY facility_count DESC;

-- 8. Find Security-Related Facilities (Security Posts, First Aid, Lost and Found)
SELECT id, name, type, location
FROM facility
WHERE type IN ('Security', 'First Aid', 'Info');

-- 9. Find the Distance Between Two Facilities
SELECT f1.name AS facility_1, f2.name AS facility_2,
       ST_Distance(f1.location, f2.location) AS distance_meters
FROM facility f1, facility f2
WHERE f1.name = 'First Aid Station' AND f2.name = 'Main Toilet A';

-- 10. Find All Attractions and Events Within 500 Meters of a Given Point
SELECT 'Event' AS category, id, name, start_time, end_time,
       ST_Distance(location, ST_SetSRID(ST_MakePoint(13.045, 47.810), 4326)) AS distance
FROM event
WHERE start_time > NOW() 
  AND ST_DWithin(location, ST_SetSRID(ST_MakePoint(13.045, 47.810), 4326), 500)
UNION ALL
SELECT 'Attraction' AS category, id, name, NULL AS start_time, NULL AS end_time,
       ST_Distance(geometry, ST_SetSRID(ST_MakePoint(13.045, 47.810), 4326)) AS distance
FROM attraction
WHERE ST_DWithin(geometry, ST_SetSRID(ST_MakePoint(13.045, 47.810), 4326), 500)
ORDER BY distance;


-- ADDITIONAL VIEWS (OPTIONAL) (I DID NOT INCLUDE THE OUTPUT OF THE FOLLOWING VIEW'S IN THE DOCUMENTATION)

-- Public view excluding any sensitive columns
CREATE VIEW public_spatial_entities AS
SELECT id, name, entity_type, geom
FROM spatial_entities;

-- Zone summary view: counts facilities and events per zone
CREATE VIEW zone_summary AS
SELECT z.id, z.name,
       COUNT(DISTINCT f.id) AS facility_count,
       COUNT(DISTINCT e.id) AS event_count
FROM zone z
LEFT JOIN facility f ON ST_Intersects(z.area, f.location)
LEFT JOIN event e ON ST_Intersects(z.area, e.location)
GROUP BY z.id, z.name;

-- Security monitoring view: shows only security-related facilities
CREATE VIEW security_facilities AS
SELECT id, name, type, location
FROM facility
WHERE type = 'Security';

-- Upcoming events view: shows events that haven't started yet
CREATE VIEW upcoming_events AS
SELECT id, name, description, start_time, end_time, location
FROM event
WHERE start_time > NOW()
ORDER BY start_time;